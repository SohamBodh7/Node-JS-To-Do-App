# Simple Notes Django App
A simple note-taking application written using python's django web framework.

![Screenshot of the home page of the app after signing in](screenshots/home_page_screenshot.png)

## Features
 - Shortcuts
 - Organize notes into notebooks
 - Export notes as PDF files
 - Share your notes via a unique link
 - Multiple themes
 - Reminders
 - Version Control

## 🚀 Deployment Guide

Follow these step-by-step instructions to deploy the Simple Notes Django App on your local machine or server. This guide covers both general setup and **Ubuntu-specific** instructions for a smooth experience. The app uses **SQLite** by default, but can be configured for **PostgreSQL**. It also supports **Redis** for sessions/cache and **Celery** for background tasks.

### 📋 Prerequisites

Before starting, ensure you have the following installed:

- **Python 3.8+**: Download from [python.org](https://www.python.org/downloads/) or use your system's package manager.
- **Pip**: Python package installer (usually comes with Python).
- **Git**: For cloning the repository.
- **Virtual Environment Tool**: `pipenv` (recommended) or `venv`.
- **Optional for Advanced Features**:
  - **Redis**: For session storage and caching.
  - **PostgreSQL**: For production database (instead of SQLite).
  - **Celery**: For background tasks (e.g., reminders).

Verify installations:
- Python: `python --version` or `python3 --version`
- Pip: `pip --version`
- Git: `git --version`

### 🐧 Ubuntu-Specific Prerequisites

If deploying on Ubuntu (e.g., 20.04+), install system dependencies:

```bash
# Update package list
sudo apt update

# Install Python 3.8+ (if not installed)
sudo apt install python3 python3-pip python3-venv

# Install Git
sudo apt install git

# Optional: Install Redis
sudo apt install redis-server
sudo systemctl start redis-server
sudo systemctl enable redis-server

# Optional: Install PostgreSQL
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Optional: Install Celery dependencies (if using Celery)
sudo apt install rabbitmq-server  # For Celery broker
sudo systemctl start rabbitmq-server
sudo systemctl enable rabbitmq-server
```

### 📥 Step 1: Clone the Repository

1. Open your terminal.
2. Navigate to your desired directory (e.g., `cd ~/projects`).
3. Clone the repo:
   ```bash
   git clone https://github.com/Namnetsy/simple-notes-django-app.git
   ```
4. Enter the project directory:
   ```bash
   cd simple-notes-django-app
   ```

### 🔧 Step 2: Set Up Environment Variables

1. Copy the example environment file:
   ```bash
   cp simple_notes/.env.example simple_notes/.env
   ```
2. Edit the `.env` file to configure settings:
   - Open `simple_notes/.env` in a text editor.
   - Set a secure `SECRET_KEY` (generate one with `python -c "import secrets; print(secrets.token_urlsafe(50))"`).
   - Configure `DEBUG=1` for development (set to `0` for production).
   - Set `ALLOWED_HOSTS` (e.g., `ALLOWED_HOSTS=localhost,127.0.0.1,yourdomain.com`).
   - If using email features, add `PEPIPOST_API_KEY`, `PEPIPOST_FROM_EMAIL`, etc.
   - **Note**: The app uses SQLite by default. For PostgreSQL, update `DATABASES` in `settings.py` accordingly.

### 📦 Step 3: Install Dependencies

Choose one of the following methods:

- **Using Pipenv** (recommended):
  ```bash
  pipenv install
  pipenv shell  # Activate the virtual environment
  ```

- **Using pip and venv**:
  ```bash
  python3 -m venv venv
  source venv/bin/activate  # On Windows: venv\Scripts\activate
  pip install -r requirements.txt
  ```

### 🗄️ Step 4: Set Up the Database

1. Run Django migrations to set up the database schema:
   ```bash
   python manage.py migrate
   ```
   - This creates tables in SQLite (or PostgreSQL if configured).

2. **Optional: Create a Superuser** for admin access:
   ```bash
   python manage.py createsuperuser
   ```
   Follow prompts to set username, email, and password.

3. **Optional: For PostgreSQL** (if switching from SQLite):
   - Create a PostgreSQL database and user.
   - Update `DATABASES` in `settings.py`:
     ```python
     DATABASES = {
         'default': {
             'ENGINE': 'django.db.backends.postgresql',
             'NAME': 'your_db_name',
             'USER': 'your_db_user',
             'PASSWORD': 'your_db_password',
             'HOST': 'localhost',
             'PORT': '5432',
         }
     }
     ```
   - Install psycopg2 if not already: `pip install psycopg2-binary`

### ▶️ Step 5: Run the Application

#### For Development
Run the Django development server:
```bash
python manage.py runserver
```
- Access at `http://127.0.0.1:8000` or `http://localhost:8000`.
- For debugging, use `python manage.py runserver --settings=simple_notes.test_settings`.

#### For Production
Use Gunicorn (recommended for production):
```bash
gunicorn --chdir simple_notes simple_notes.wsgi --preload --bind 0.0.0.0:8000
```
- **Note**: Set `DEBUG=0` in `.env` and configure a reverse proxy (e.g., Nginx) for production.

### 🔄 Optional: Advanced Setup

#### Redis for Sessions and Caching
- Ensure Redis is running (`redis-server`).
- Sessions and cache are already configured in `settings.py` to use Redis at `localhost:6379`.

#### Celery for Background Tasks
- Start Celery worker:
  ```bash
  celery -A simple_notes worker --loglevel=info
  ```
- For reminders/tasks, Celery is set up with Redis as broker/result backend.

#### Static Files
- For production, collect static files:
  ```bash
  python manage.py collectstatic
  ```
- Served via WhiteNoise middleware.

### 🐧 Ubuntu-Specific Deployment

For a complete Ubuntu setup:

1. Follow **Ubuntu-Specific Prerequisites** above.
2. Clone, set up `.env`, install deps, migrate DB as in general steps.
3. To run as a service:
   - Create a systemd service file for Gunicorn (e.g., `/etc/systemd/system/simple-notes.service`):
     ```
     [Unit]
     Description=Simple Notes Django App
     After=network.target

     [Service]
     User=your_user
     Group=your_group
     WorkingDirectory=/path/to/simple-notes-django-app
     Environment="PATH=/path/to/venv/bin"
     ExecStart=/path/to/venv/bin/gunicorn --chdir simple_notes simple_notes.wsgi --preload --bind 0.0.0.0:8000
     Restart=always

     [Install]
     WantedBy=multi-user.target
     ```
   - Enable and start: `sudo systemctl enable simple-notes && sudo systemctl start simple-notes`
4. Set up Nginx as reverse proxy (install with `sudo apt install nginx`):
   - Create config in `/etc/nginx/sites-available/simple-notes`:
     ```
     server {
         listen 80;
         server_name your_domain_or_ip;

         location / {
             proxy_pass http://127.0.0.1:8000;
             proxy_set_header Host $host;
             proxy_set_header X-Real-IP $remote_addr;
             proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
             proxy_set_header X-Forwarded-Proto $scheme;
         }

         location /static/ {
             alias /path/to/simple-notes-django-app/assets/;
         }
     }
     ```
   - Enable: `sudo ln -s /etc/nginx/sites-available/simple-notes /etc/nginx/sites-enabled/`
   - Restart Nginx: `sudo systemctl restart nginx`

### 🐛 Troubleshooting

- **Port Issues**: Change port in `runserver` or Gunicorn bind.
- **Database Errors**: Ensure DB is running and credentials are correct.
- **Static Files Not Loading**: Run `collectstatic` and check `STATIC_ROOT`.
- **Permission Errors**: Use `sudo` for system-level commands.
- **Logs**: Check Django logs in console or configure logging in `settings.py`.

If issues persist, check the [Django documentation](https://docs.djangoproject.com/en/4.1/) or open an issue on GitHub.
