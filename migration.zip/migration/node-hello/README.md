# 🚀 Node Hello World

A simple Node.js application that serves "Hello World" – perfect for testing basic deployments to the cloud!

## ✨ Project Overview

This is a minimal Node.js app designed to demonstrate a basic web server setup. It's ideal for beginners learning Node.js or for quick cloud deployment tests.

## 🛠️ Prerequisites

- **Node.js**: Version 14+ recommended. Download from [nodejs.org](https://nodejs.org/).
- **npm**: Comes with Node.js.
- **Git**: For cloning the repo.
- A code editor (e.g., VS Code).

Verify installations:
- Node.js: `node -v`
- npm: `npm -v`

## 📦 Step-by-Step Setup Guides

Choose your operating system below for detailed instructions.

### 🪟 Windows Setup

#### 1. Install Node.js
- Go to [nodejs.org](https://nodejs.org/) and download the LTS version.
- Run the installer (.msi file).
- Follow the setup wizard; accept defaults.
- Restart your terminal/command prompt if needed.

#### 2. Verify Installation
- Open Command Prompt or PowerShell.
- Type:
  ```bash
  node -v
  npm -v
  ```
- You should see version numbers.

#### 3. Clone the Project
- Install Git if not installed: [git-scm.com](https://git-scm.com/).
- Open Command Prompt.
- Navigate to your desired folder (e.g., `cd Desktop`).
- Clone:
  ```bash
  git clone https://github.com/johnpapa/node-hello.git
  cd node-hello
  ```

#### 4. Install Dependencies
- In the project folder:
  ```bash
  npm install
  ```
- Wait for installation to complete.

#### 5. Run the App
- Start the server:
  ```bash
  npm start
  ```
- Open browser to `http://localhost:3000`.
- You should see "Hello Node!".

### 🍎 macOS Setup

#### 1. Install Node.js
- Option 1: Download from [nodejs.org](https://nodejs.org/) and run the .pkg installer.
- Option 2: Use Homebrew (recommended):
  - Install Homebrew if not installed: `/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"`
  - Then: `brew install node`

#### 2. Verify Installation
- Open Terminal.
- Type:
  ```bash
  node -v
  npm -v
  ```
- You should see version numbers.

#### 3. Clone the Project
- Open Terminal.
- Navigate to your desired folder (e.g., `cd Desktop`).
- Clone:
  ```bash
  git clone https://github.com/johnpapa/node-hello.git
  cd node-hello
  ```

#### 4. Install Dependencies
- In the project folder:
  ```bash
  npm install
  ```
- Wait for installation to complete.

#### 5. Run the App
- Start the server:
  ```bash
  npm start
  ```
- Open browser to `http://localhost:3000`.
- You should see "Hello Node!".

## 🐛 Troubleshooting

- **Port 3000 in use**: Change port in `index.js` or set `PORT=3001 npm start`.
- **npm install fails**: Clear cache with `npm cache clean --force` and retry.
- **Permission errors on macOS**: Use `sudo` for global installs, but avoid for project deps.
- **Node not found**: Restart terminal or check PATH.
- **Firewall blocks**: Allow Node.js in firewall settings.

## 🚀 Alternative Ways to Run

- **Directly**: `node index.js`
- **With nodemon** (for development): `npm install -g nodemon` then `nodemon index.js`
- **Docker**: Create a Dockerfile and run with Docker Compose.

## 📁 Project Structure

```
node-hello/
├── index.js          # Main application file
├── package.json      # Project dependencies and scripts
├── package-lock.json # Lockfile for exact dependency versions
├── .gitignore        # Files to ignore in Git
├── .prettierrc       # Prettier configuration
└── README.md         # This file
```

## 🌐 Deployment

This app is great for testing deployments on platforms like Heroku, Vercel, or AWS. Just push to your cloud provider and follow their Node.js deployment guides!

Enjoy coding! 🎉
