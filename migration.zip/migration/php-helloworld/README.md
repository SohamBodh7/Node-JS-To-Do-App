# 🚀 PHP Hello World Project Setup

This guide walks you through setting up and running a simple PHP "Hello World" project in easy baby steps. Choose your operating system below for tailored instructions.

## 📋 Prerequisites

- A code editor (e.g., VS Code, Sublime Text).
- Internet connection for downloads.
- Basic command-line knowledge.

## 🪟 Windows Setup Guide

### 1. Get the Project Code

- Visit the GitHub repository: [https://github.com/sanjurajrh/php-helloworld](https://github.com/sanjurajrh/php-helloworld)
- Download or clone the project to your computer.

### 2. Download PHP

- Go to the official PHP download page: [https://www.php.net/downloads.php](https://www.php.net/downloads.php)
- Download the **Thread Safe** zip file for your Windows version.

### 3. Install and Configure PHP

- **Extract the zip file**: Unzip it to a permanent folder, like `C:\php`.
- **Add to PATH**:
  - Right-click on "This PC" or "My Computer" and select "Properties".
  - Click "Advanced system settings" > "Environment Variables".
  - Under "System variables", find "Path", click "Edit", and add `C:\php` (or your chosen folder).
  - Click "OK" to save.

### 4. Open Project and Verify Installation

- Open your code editor (like VS Code) and load the `php-helloworld` folder.
- Open a terminal in your editor or command prompt.
- Check PHP is installed by typing:

  ```bash
  php -v
  ```

  You should see the PHP version displayed.

### 5. Run the Project

- In the terminal, start the built-in PHP server:

  ```bash
  php -S 127.0.0.1:8000
  ```

- Open your web browser and go to: `http://127.0.0.1:8000`
- You should see the "Hello World" page!

That's it! Your PHP project is now running locally.

## 🐧 Ubuntu Setup Guide

### 1. Update Your System

- Open a terminal and update your package list:

  ```bash
  sudo apt update
  sudo apt upgrade -y
  ```

### 2. Install PHP

- Install PHP and the CLI module:

  ```bash
  sudo apt install php php-cli -y
  ```

- Verify installation:

  ```bash
  php -v
  ```

  You should see the PHP version (e.g., PHP 8.x).

### 3. Get the Project Code

- Install Git if not already installed:

  ```bash
  sudo apt install git -y
  ```

- Clone the repository:

  ```bash
  git clone https://github.com/sanjurajrh/php-helloworld.git
  cd php-helloworld
  ```

### 4. Run the Project

- Start the built-in PHP server:

  ```bash
  php -S 127.0.0.1:8000
  ```

- Open your web browser and navigate to: `http://127.0.0.1:8000`
- You should see the "Hello World" message with PHP version and OpenShift note!

### 5. Optional: Install Additional PHP Extensions

If your project needs more features, install common extensions:

```bash
sudo apt install php-mysql php-xml php-curl php-zip -y
```

## 🐳 Docker Alternative (Using Docker Compose)

If you prefer containerized setup, use the provided `compose.yaml` (note: it's for WordPress, but demonstrates Docker usage).

### Prerequisites

- Install Docker: [https://docs.docker.com/get-docker/](https://docs.docker.com/get-docker/)
- Install Docker Compose: [https://docs.docker.com/compose/install/](https://docs.docker.com/compose/install/)

### Steps

1. Ensure Docker is running.
2. In the project directory, run:

   ```bash
   docker-compose up -d
   ```

3. Access the app at `http://localhost:8080` (for the WordPress setup in compose.yaml).

For a simple PHP container, you can create a custom Dockerfile, but the compose.yaml is for a different demo.

## 🐛 Troubleshooting

- **PHP not found**: Ensure PHP is added to PATH (Windows) or installed via apt (Ubuntu).
- **Port 8000 in use**: Change to another port, e.g., `php -S 127.0.0.1:8080`.
- **Permission errors**: On Ubuntu, use `sudo` for system commands.
- **Browser shows code**: Ensure you're accessing via `http://`, not `file://`.
- **Docker issues**: Check Docker daemon is running with `docker ps`.

## 🎉 What's Next?

- Explore the `index.php` file to understand the code.
- Add more PHP features like forms or databases.
- Deploy to a server like Heroku or AWS for production.

Happy coding! 🚀
