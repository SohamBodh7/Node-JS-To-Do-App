# Ruby Hello World - Key-Value Store API

A simple Ruby Sinatra application that provides a RESTful key-value store API using MySQL as the backend database. This project demonstrates basic CRUD operations for key-value pairs and includes database migrations, testing, and Docker support.

## Is This an Easy Project?

Yes, this is an easy project for beginners! It's a straightforward Sinatra app with basic Ruby knowledge required. No complex frameworks or advanced concepts—just simple API endpoints, database interactions, and standard Ruby tooling. Perfect for learning Ruby web development and database integration.

## Prerequisites

- Ruby (version 2.7 or higher recommended)
- MySQL database (local or remote)
- Bundler (Ruby gem manager)
- Git (for cloning the repository)

### For Windows:
- Install Ruby from [rubyinstaller.org](https://rubyinstaller.org/)
- Install MySQL from [mysql.com](https://dev.mysql.com/downloads/mysql/)

### For Ubuntu:
- Ruby and MySQL can be installed via package manager

## Installation

### Windows

1. **Clone the repository:**
   ```bash
   git clone <repository-url>
   cd ruby-hello-world
   ```

2. **Install Ruby dependencies:**
   ```bash
   bundle install
   ```

3. **Set up MySQL database:**
   - Start MySQL service (if not running).
   - Create a database named `myapp_development` (or set `MYSQL_DATABASE` env var).
   - Set environment variables (create a `.env` file or set in command prompt):
     ```
     set MYSQL_DATABASE=myapp_development
     set MYSQL_USER=root
     set MYSQL_PASSWORD=your_password
     set DATABASE_SERVICE_HOST=localhost
     set DATABASE_SERVICE_PORT=3306
     ```

4. **Run database setup:**
   ```bash
   rake db:create
   rake db:migrate
   ```

### Ubuntu

1. **Install Ruby and MySQL:**
   ```bash
   sudo apt update
   sudo apt install ruby-full mysql-server
   sudo mysql_secure_installation
   ```

2. **Clone the repository:**
   ```bash
   git clone <repository-url>
   cd ruby-hello-world
   ```

3. **Install Ruby dependencies:**
   ```bash
   bundle install
   ```

4. **Set up MySQL database:**
   - Start MySQL service:
     ```bash
     sudo systemctl start mysql
     ```
   - Create a database:
     ```bash
     sudo mysql -u root -p
     CREATE DATABASE myapp_development;
     EXIT;
     ```
   - Set environment variables (add to `~/.bashrc` or set in terminal):
     ```bash
     export MYSQL_DATABASE=myapp_development
     export MYSQL_USER=root
     export MYSQL_PASSWORD=your_password
     export DATABASE_SERVICE_HOST=localhost
     export DATABASE_SERVICE_PORT=3306
     ```

5. **Run database setup:**
   ```bash
   rake db:create
   rake db:migrate
   ```

## Running the Application

### Local Development

1. **Start the app:**
   ```bash
   ruby app.rb
   ```
   Or using the provided script:
   ```bash
   ./run.sh
   ```

2. **Access the app:**
   - Open your browser to `http://localhost:8080`
   - API endpoints are available at the same URL

### Using Docker

1. **Build the Docker image:**
   ```bash
   docker build -t ruby-hello-world .
   ```

2. **Run the container:**
   ```bash
   docker run -p 8080:8080 ruby-hello-world
   ```

   Note: Ensure MySQL is running separately or use Docker Compose for full setup.

## Testing

Run the test suite:
```bash
rake test
```

## API Endpoints

- `GET /` - Main page (renders ERB template)
- `GET /keys` - Retrieve all key-value pairs
- `GET /keys/:id` - Retrieve value for a specific key
- `POST /keys/:id` - Create or update a key-value pair (send `value` in body)
- `DELETE /keys/:id` - Delete a key-value pair

Example usage with curl:
```bash
# Create a key
curl -X POST -d "value=hello" http://localhost:8080/keys/mykey

# Get a key
curl http://localhost:8080/keys/mykey

# Delete a key
curl -X DELETE http://localhost:8080/keys/mykey
```

## Project Structure

- `app.rb` - Main Sinatra application
- `models.rb` - ActiveRecord model for KeyPair
- `config/database.rb` - Database connection logic
- `config/database.yml` - Database configuration
- `db/migrate/` - Database migrations
- `views/main.erb` - ERB template for the main page
- `test/` - Test files
- `Gemfile` - Ruby dependencies
- `Dockerfile` - Docker configuration
- `run.sh` - Startup script

## Contributing

Feel free to fork and submit pull requests!

## License

This project is a sample application and may be used for educational purposes.

