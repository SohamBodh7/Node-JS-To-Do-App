# 🚀 Simple PHP Form Submission App

A basic, two-page PHP application (`index.php` and `submit.php`) designed for learning fundamental form handling and server deployment.

## ✨ Project Overview

This project demonstrates a standard HTML form submission process:

- **index.php**: Contains a simple HTML form with Name and Email fields.
- **submit.php**: Receives the form data, performs basic validation, and displays the submitted information back to the user.

## 🛠️ Prerequisites (The "Baby Guide")

To run any PHP application, you need a web server (like Apache) and the PHP interpreter installed. The easiest way to get both is by installing a bundle.

| Operating System | Recommended Bundle |
|------------------|---------------------|
| Windows          | XAMPP               |
| Linux            | LAMP Stack (Linux, Apache, MySQL, PHP) |
| macOS            | MAMP                |

### Step 1: Install a Web Stack (XAMPP for Windows)

This is the simplest way to get PHP running locally on your Windows machine.

1. **Download XAMPP**: Go to the [official Apache Friends XAMPP website](https://www.apachefriends.org/) and download the installer for Windows.
2. **Install**: Run the installer. You can keep all default settings.
3. **Start XAMPP**: Once installed, open the XAMPP Control Panel.
4. **Start Services**: Click the Start button next to Apache and MySQL. Apache is the web server that runs your PHP code. (MySQL is not needed for this app, but good practice).
5. **Locate the Web Root**: The folder where XAMPP looks for web files is called `htdocs`. This folder is located here:

   ```
   C:\xampp\htdocs
   ```

## 💻 Deployment Steps

Follow the instructions below based on your target environment.

### A. Windows Local Deployment (`C:\php_lab17`)

1. **Create Project Folder**: Navigate to your `htdocs` directory and create the folder structure requested:

   ```
   C:\xampp\htdocs\php_lab17
   ```

2. **Clone Project**: Place the two files (`index.php` and `submit.php`) directly into the new `php_lab17` folder.
3. **Run the App**: Open your web browser and navigate to the following address:

   ```
   http://localhost/php_lab17/
   ```

   You should see the form displayed!

### B. Linux Server Deployment (`/home/student/php_lab17/`)

For a standard Linux environment (like Ubuntu or Debian), you will need to install Apache and PHP manually.

#### 1. Linux Prerequisite Installation (If not already installed)

Open your terminal and run these commands to install the necessary components:

```bash
# Update package list
sudo apt update

# Install Apache Web Server
sudo apt install apache2

# Install PHP and the Apache integration module
# We install php-cli as well just in case
sudo apt install php libapache2-mod-php php-cli

# Verify installation (should show versions)
apache2 -v
php -v
```

#### 2. Project Deployment

- **Locate Web Root**: The default web server root for Apache on Linux is:

  ```
  /var/www/html/
  ```

- **Create Project Folder**: Since you requested to deploy the app from your home directory (`/home/student/php_lab17/`), we must tell Apache where to find it. The easiest way is to use a symbolic link.

  ```bash
  # 1. Create your project folder in your home directory
  mkdir -p /home/student/php_lab17

  # 2. Move or clone your two files into this directory
  # (Assume your files are now in /home/student/php_lab17/)

  # 3. Create a symbolic link from the web root to your project folder
  # This makes your project accessible via the web server
  sudo ln -s /home/student/php_lab17 /var/www/html/php_lab17

  # 4. Give Apache read permission to your project folder
  # NOTE: This is critical for files outside of /var/www/html/
  sudo chmod -R 755 /home/student/php_lab17

  # 5. Optional: Restart Apache to ensure the changes take effect
  sudo systemctl restart apache2
  ```

- **Run the App**: Open your web browser and use your server's IP address or hostname:

  ```
  http://[Your Server IP or Hostname]/php_lab17/
  ```

## 📂 Project Structure

```
php_lab17/
├── index.php      # The main form page
├── submit.php     # The page that processes the form data
└── README.md      # This deployment guide
```
