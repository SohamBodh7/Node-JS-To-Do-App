<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simple PHP Form</title>
    <style>
        body { font-family: 'Arial', sans-serif; background-color: #f4f7f6; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; }
        .container { background-color: white; padding: 40px; border-radius: 12px; box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1); width: 100%; max-width: 400px; }
        h1 { color: #333; text-align: center; margin-bottom: 30px; }
        label { display: block; margin-bottom: 8px; color: #555; font-weight: bold; }
        input[type="text"], input[type="email"] { width: 100%; padding: 12px; margin-bottom: 20px; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box; transition: border-color 0.3s; }
        input[type="text"]:focus, input[type="email"]:focus { border-color: #007bff; outline: none; }
        button { background-color: #007bff; color: white; padding: 12px 20px; border: none; border-radius: 6px; cursor: pointer; font-size: 16px; width: 100%; transition: background-color 0.3s, transform 0.1s; }
        button:hover { background-color: #0056b3; }
        button:active { transform: scale(0.99); }
    </style>
</head>
<body>

<div class="container">
    <h1>Contact Details Form</h1>
    <!-- The form submits data to submit.php using the POST method -->
    <form action="submit.php" method="POST">
        
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required placeholder="Enter your full name">

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required placeholder="Enter your email address">

        <button type="submit">Submit Details</button>
    </form>
</div>

</body>
</html>