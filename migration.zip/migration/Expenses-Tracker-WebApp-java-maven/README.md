![Language](https://img.shields.io/badge/language-Java%20-blue.svg)
![Technologies](https://img.shields.io/badge/technologies-Spring_boot%20-green.svg)
![Technologies](https://img.shields.io/badge/technologies-Spring_MVC%20-green.svg)
![Technologies](https://img.shields.io/badge/technologies-Spring_Security%20-green.svg)
![Technologies](https://img.shields.io/badge/technologies-Spring_Data_jpa%20-green.svg)
![Technologies](https://img.shields.io/badge/technologies-Thymeleaf_&_Bootstrap%20-purple.svg)

# Expenses-Tracker-WebApp
## Overview
The Expenses Tracker App is a robust financial management solution developed using cutting-edge technologies such as Spring Boot, Spring Security, and MySQL. With user authentication and authorization features, users can securely sign up, sign in, and perform CRUD operations on their expenses. The app's intuitive interface, powered by Thymeleaf and Bootstrap, ensures a seamless user experience. The filtering functionality allows users to efficiently organize and analyze their financial data. Explore the power of streamlined expense tracking and financial control with this feature-rich application.<br> (Screenshots below for more illustration)

## Technologies Used
- Java
- Spring boot
- Spring MVC
- Spring Security
- Spring Data (JPA)
- MySQL
- Thymeleaf
- Bootstrap

## Features
- **User Authentication and Authorization:** Securely sign up, sign in, and access the app with built-in authentication and authorization.
- **CRUD Operations:** Perform essential financial tracking actions such as adding, reading, updating, and deleting expenses.
- **Filtering:** Utilize the filtering feature to efficiently sort and view expenses based on various criteria.

## 🚀 Step-by-Step Installation Guide

Follow these baby-step guides to run the Expenses Tracker WebApp on your local machine. Choose your operating system below for tailored instructions.

### 📋 Prerequisites

- **Java 17**: Required for Spring Boot.
- **Apache Maven**: For building the project.
- **MySQL Server**: Database backend.
- **Git**: For cloning the repo.
- A code editor (e.g., VS Code).

Verify installations:
- Java: `java -version`
- Maven: `mvn -version`
- MySQL: `mysql --version`

## 🪟 Windows Setup Guide

### Step 1: Install Java 17
1. Go to [Oracle JDK 17](https://www.oracle.com/java/technologies/javase/jdk17-archive-downloads.html) or [OpenJDK](https://openjdk.java.net/install/).
2. Download the Windows installer (.exe).
3. Run the installer and follow prompts.
4. Set `JAVA_HOME` environment variable to the JDK path (e.g., `C:\Program Files\Java\jdk-17`).
5. Add `%JAVA_HOME%\bin` to PATH.

### Step 2: Install Maven
1. Download from [Maven Official Site](https://maven.apache.org/download.cgi).
2. Unzip to a folder (e.g., `C:\maven`).
3. Add `C:\maven\bin` to PATH.
4. Verify: `mvn -version`.

### Step 3: Install MySQL
1. Download MySQL Installer from [MySQL Site](https://dev.mysql.com/downloads/mysql/).
2. Run installer, select "Developer Default".
3. Set root password (remember it!).
4. Start MySQL service.

### Step 4: Install Git
1. Download from [Git Site](https://git-scm.com/downloads).
2. Run installer with defaults.

### Step 5: Clone the Project
1. Open Command Prompt.
2. `cd Desktop` (or your preferred folder).
3. `git clone https://github.com/your-username/expenses-tracker.git`
4. `cd expenses-tracker`

### Step 6: Set Up Database
1. Open MySQL Command Line Client.
2. Login: `mysql -u root -p` (enter password).
3. Run: `source sql_script.sql`
4. Create user: `CREATE USER 'springstudent'@'localhost' IDENTIFIED BY 'springstudent';`
5. Grant: `GRANT ALL PRIVILEGES ON expenses_tracker.* TO 'springstudent'@'localhost'; FLUSH PRIVILEGES;`
6. Exit: `exit`

### Step 7: Build and Run
1. `mvn clean install` (wait for success).
2. `java -jar target\ExpensesTracker-0.0.1-SNAPSHOT.jar`
3. Open browser to `http://localhost:8080`.

## 🐧 Ubuntu Setup Guide

### Step 1: Update System
```bash
sudo apt update
sudo apt upgrade -y
```

### Step 2: Install Java 17
```bash
sudo apt install openjdk-17-jdk -y
java -version
```

### Step 3: Install Maven
```bash
sudo apt install maven -y
mvn -version
```

### Step 4: Install MySQL
```bash
sudo apt install mysql-server -y
sudo systemctl start mysql
sudo systemctl enable mysql
sudo mysql_secure_installation
```

### Step 5: Install Git
```bash
sudo apt install git -y
```

### Step 6: Clone the Project
```bash
git clone https://github.com/your-username/expenses-tracker.git
cd expenses-tracker
```

### Step 7: Set Up Database
```bash
sudo mysql -u root -p < sql_script.sql
sudo mysql -u root -p -e "CREATE USER 'springstudent'@'localhost' IDENTIFIED BY 'springstudent'; GRANT ALL PRIVILEGES ON expenses_tracker.* TO 'springstudent'@'localhost'; FLUSH PRIVILEGES;"
```

### Step 8: Build and Run
```bash
mvn clean install
java -jar target/ExpensesTracker-0.0.1-SNAPSHOT.jar
```
- Access at `http://localhost:8080`.

## 🐛 Troubleshooting

- **Java not found**: Check PATH and JAVA_HOME.
- **Maven build fails**: Ensure internet for dependencies.
- **MySQL connection error**: Verify user credentials in `application.properties`.
- **Port 8080 busy**: Change in `application.properties`: `server.port=8081`
- **Permission issues**: Use `sudo` on Ubuntu.

## 🎉 You're Done!

Register a user and start tracking expenses! 🚀

## ScreenShots
![Example Image](screenshots/1.png) <br>
![Example Image](screenshots/2-2.png) <br>
![Example Image](screenshots/3-3.png) <br>
![Example Image](screenshots/4-4.png) <br>
![Example Image](screenshots/5-5.png) <br>
![Example Image](screenshots/6-6.png) <br>
![Example Image](screenshots/7.png) <br>
![Example Image](screenshots/8.png) <br>

## Contributions
Contributions are welcome! If you find a bug or have suggestions for improvement, feel free to open an issue or create a pull request.

## License
This project is licensed under the MIT License.
