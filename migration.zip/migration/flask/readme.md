# 🚀 Flask Todo App Deployment Guide

A simple Flask-based Todo application with SQLite database for managing tasks. This guide provides step-by-step instructions to deploy the app locally, with special focus on Ubuntu setup.

## 📋 Prerequisites

- **Python 3.8+**: Required for Flask.
- **pip**: Python package manager.
- **Git**: For cloning the repo.
- A code editor (e.g., VS Code).

Verify installations:
- Python: `python --version` or `python3 --version`
- pip: `pip --version`

## 🐧 Ubuntu Setup Guide

### Step 1: Update System Packages
```bash
sudo apt update
sudo apt upgrade -y
```

### Step 2: Install Python and pip
```bash
sudo apt install python3 python3-pip python3-venv -y
```

### Step 3: Install Git
```bash
sudo apt install git -y
```

### Step 4: Clone the Repository
```bash
git clone <your-repo-url>
cd flask-todo-app  # Replace with actual folder name
```

### Step 5: Set Up Virtual Environment
```bash
python3 -m venv venv
source venv/bin/activate
```

### Step 6: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 7: Run the Application
```bash
python app.py
```

### Step 8: Access the App
- Open browser to `http://localhost:5000` (Flask default port).
- Add, update, delete todos!

### Optional: Production Deployment on Ubuntu
- Install Gunicorn: `pip install gunicorn`
- Run with: `gunicorn -w 4 -b 0.0.0.0:8000 app:app`
- Set up Nginx reverse proxy for production.

## 🪟 Windows/macOS Setup Guide

### Step 1: Install Python
- Download from [python.org](https://python.org).
- Run installer, check "Add to PATH".

### Step 2: Install Git
- Download from [git-scm.com](https://git-scm.com).

### Step 3: Clone Repository
```bash
git clone <your-repo-url>
cd flask-todo-app
```

### Step 4: Create Virtual Environment
- Windows: `python -m venv venv`
- macOS: `python3 -m venv venv`
- Activate: `venv\Scripts\activate` (Windows) or `source venv/bin/activate` (macOS)

### Step 5: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 6: Run App
```bash
python app.py
```

### Step 7: Access
- Browser: `http://localhost:5000`

## 🗂️ Project Structure

```
flask-todo-app/
├── app.py              # Main Flask app
├── db.py               # SQLite database operations
├── requirements.txt    # Python dependencies
├── todo.sqlite         # SQLite database file
├── static/             # CSS, JS, images
│   ├── css/
│   ├── js/
│   └── image/
├── templates/          # HTML templates
│   └── todo.html
└── readme.md           # This file
```

## 🐛 Troubleshooting

- **Port 5000 in use**: Change port in `app.py` (e.g., `app.run(port=5001)`).
- **Import errors**: Ensure virtual env is activated.
- **Database issues**: Delete `todo.sqlite` to reset.
- **Permission errors**: Use `sudo` on Ubuntu for system installs.
- **Flask not found**: Install with `pip install flask`.

## 🌟 Features

- Add, edit, delete todos
- SQLite database
- Responsive UI with Bootstrap
- RESTful API endpoints

## 🚀 Next Steps

- Deploy to Heroku/AWS
- Add user authentication
- Switch to PostgreSQL for production

Happy coding! 🎉

