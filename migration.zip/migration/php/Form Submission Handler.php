<?php
// Check if the form was submitted using the POST method
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // 1. Sanitize and retrieve data
    // Use filter_input for security, falling back to $_POST directly if needed
    $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING) ?? $_POST['name'] ?? 'N/A';
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL) ?? $_POST['email'] ?? 'N/A';

    // Basic validation check (optional, but good practice)
    if (empty(trim($name)) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message_class = 'error';
        $title = 'Submission Error';
        $content = 'Please go back and ensure both fields are filled out correctly (especially the email).';
    } else {
        // 2. Process data (in a real app, you would save this to a database)
        // For this simple example, we just prepare a success message.
        $message_class = 'success';
        $title = 'Submission Successful!';
        $content = "Thank you, **{$name}**, for submitting your details. <br>We received the following email: **{$email}**.";
    }

} else {
    // If accessed directly without a POST request
    $message_class = 'error';
    $title = 'Invalid Access';
    $content = 'This page should only be accessed via the form submission.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $title; ?></title>
    <style>
        body { font-family: 'Arial', sans-serif; background-color: #f4f7f6; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; text-align: center; }
        .container { background-color: white; padding: 40px; border-radius: 12px; box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1); width: 100%; max-width: 500px; }
        h1 { margin-bottom: 20px; }
        .success h1 { color: #28a745; }
        .error h1 { color: #dc3545; }
        p { color: #333; font-size: 1.1em; line-height: 1.6; }
        strong { font-weight: bold; color: #007bff; }
        .back-button { margin-top: 30px; text-decoration: none; background-color: #6c757d; color: white; padding: 10px 20px; border-radius: 6px; display: inline-block; transition: background-color 0.3s; }
        .back-button:hover { background-color: #5a6268; }
    </style>
</head>
<body>

<div class="container <?php echo $message_class; ?>">
    <h1><?php echo $title; ?></h1>
    <p><?php echo $content; ?></p>
    <a href="index.php" class="back-button">Go Back to Form</a>
</div>

</body>
</html>