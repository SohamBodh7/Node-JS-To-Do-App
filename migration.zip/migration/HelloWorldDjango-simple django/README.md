# Helloworld, Django

Código produzido como parte do artigo sobre Desenvolvimento Web com Django da Python Academy. 
[Acesse aqui](https://pythonacademy.com.br/blog/desenvolvimento-web-com-python-e-django-introducao) 
e saiba mais!

## 🚀 Step-by-Step Installation and Running Guide

Follow these baby-step guides to set up and run the Django Hello World project on your local machine. Choose your operating system below for tailored instructions.

### 📋 Prerequisites

- **Python 3.8+**: Required for Django.
- **pip**: Python package manager.
- **Git**: For cloning the repo.
- A code editor (e.g., VS Code).

Verify installations:
- Python: `python --version`
- pip: `pip --version`

## 🪟 Windows Setup Guide

### Step 1: Install Python
1. Go to [python.org](https://python.org).
2. Download the latest Python installer.
3. Run installer, check "Add to PATH".
4. Verify: `python --version`.

### Step 2: Install Git
1. Download from [git-scm.com](https://git-scm.com).
2. Run installer with defaults.

### Step 3: Clone the Project
1. Open Command Prompt.
2. `cd Desktop` (or your folder).
3. `git clone <your-repo-url>`
4. `cd HelloWorldDjango-simple-django`

### Step 4: Create Virtual Environment
1. `python -m venv venv`
2. Activate: `venv\Scripts\activate`

### Step 5: Install Dependencies
1. `pip install -r requirements.txt`

### Step 6: Set Up Database
1. `python manage.py makemigrations`
2. `python manage.py migrate`

### Step 7: Run the App
1. `python manage.py runserver`
2. Open browser to `http://127.0.0.1:8000`.

## 🐧 Ubuntu Setup Guide

### Step 1: Update System
```bash
sudo apt update
sudo apt upgrade -y
```

### Step 2: Install Python and pip
```bash
sudo apt install python3 python3-pip python3-venv -y
```

### Step 3: Install Git
```bash
sudo apt install git -y
```

### Step 4: Clone the Project
```bash
git clone <your-repo-url>
cd HelloWorldDjango-simple-django
```

### Step 5: Create Virtual Environment
```bash
python3 -m venv venv
source venv/bin/activate
```

### Step 6: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 7: Set Up Database
```bash
python manage.py makemigrations
python manage.py migrate
```

### Step 8: Run the App
```bash
python manage.py runserver
```
- Access at `http://127.0.0.1:8000`.

## 🐛 Troubleshooting

- **Port 8000 busy**: Change port: `python manage.py runserver 8001`
- **Import errors**: Ensure virtual env is activated.
- **Migration issues**: Delete `db.sqlite3` and rerun migrations.
- **Permission errors**: Use `sudo` on Ubuntu.

## 🎉 You're Done!

Explore the Django ERP app! 🚀

## Fique por dentro

Se gostou do conteúdo, siga a Python Academy no nosso blog e redes sociais!

- [Site](https://pythonacademy.com.br)
- [Facebook](https://facebook.com.br/pythonacademy/)
- [Blog](https://pythonacademy.com.br/blog/)

E até a próxima!
